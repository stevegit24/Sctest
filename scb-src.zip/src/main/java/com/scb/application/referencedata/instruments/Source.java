package com.scb.application.referencedata.instruments;

public enum  Source {
    LME,
    PRIME
}
