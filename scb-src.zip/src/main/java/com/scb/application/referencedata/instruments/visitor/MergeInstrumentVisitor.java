package com.scb.application.referencedata.instruments.visitor;

import com.scb.application.referencedata.instruments.Instrument;

public interface MergeInstrumentVisitor extends InstrumentVisitor<Instrument, Instrument> {
}
